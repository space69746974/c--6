#include <stdio.h>
int main(void){ int scores[]={10,20,30,40,50}; int i; int size=(int)(sizeof(scores)/sizeof(scores[0])); printf("배열 크기 = %zu bytes\n",sizeof(scores)); printf("배열 원소 개수 = %d\n",size); for(i=0;i<size;i++) printf("%d ",scores[i]); printf("\n"); return 0; }
