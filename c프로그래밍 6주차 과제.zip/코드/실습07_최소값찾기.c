#include <stdio.h>
#define SIZE 10
int main(void){ int prices[SIZE]={28,81,60,83,67,10,66,97,37,94}; int i,minimum; printf("---------------------------------------\n1 2 3 4 5 6 7 8 9 10\n---------------------------------------\n"); for(i=0;i<SIZE;i++) printf("%-3d ",prices[i]); printf("\n\n"); minimum=prices[0]; for(i=1;i<SIZE;i++) if(prices[i]<minimum) minimum=prices[i]; printf("최소값은 %d입니다.\n",minimum); return 0; }
