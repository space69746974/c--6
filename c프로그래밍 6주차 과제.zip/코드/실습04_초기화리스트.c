#include <stdio.h>
int main(void){ int a[5]={1,2,3}; int b[]={4,5,6,7}; int i; printf("a: "); for(i=0;i<5;i++) printf("%d ",a[i]); printf("\nb: "); for(i=0;i<4;i++) printf("%d ",b[i]); printf("\n"); return 0; }
