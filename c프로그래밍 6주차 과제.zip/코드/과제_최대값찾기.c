#include <stdio.h>
#define SIZE 10
int main(void){ int prices[SIZE]={28,81,60,83,67,10,66,97,37,94}; int i,maximum; printf("배열: "); for(i=0;i<SIZE;i++) printf("%d ",prices[i]); maximum=prices[0]; for(i=1;i<SIZE;i++) if(prices[i]>maximum) maximum=prices[i]; printf("\n최대값은 %d입니다.\n",maximum); return 0; }
