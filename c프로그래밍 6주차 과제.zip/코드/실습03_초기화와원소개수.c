#include <stdio.h>
int main(void){ int a[]={1,2,3,4,5,6}; int i; int size=(int)(sizeof(a)/sizeof(a[0])); for(i=0;i<size;i++) printf("a[%d] = %d\n",i,a[i]); printf("원소 개수 = %d\n",size); return 0; }
